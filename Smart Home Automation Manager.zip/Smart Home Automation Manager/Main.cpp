#include <iostream>
#include "SmartHomeManager.h"
using namespace std;
int main() {
    SmartHomeManager manager;

    manager.AddDevice(make_shared<SecurityCamera>(1, "Front Door Camera", "CamCorp", "1080p", "Battery"));
    manager.AddDevice(make_shared<Thermostat>(2, "Living Room Thermostat", "ThermoPro"));
    manager.AddDevice(make_shared<SmartSpeaker>(3, "Kitchen Speaker", "SoundBlast", 75));
    manager.AddDevice(make_shared<SmartLight>(4, "Bedroom Light", "Lightify", 80, "RGB"));

    int choice;
    do {
        cout << "\nSmart Home Manager\n";
        cout << "1. List Devices\n";
        cout << "2. Activate All Devices\n";
        cout << "3. Deactivate All Devices\n";
        cout << "4. Interact with All Devices\n";
        cout << "0. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            manager.ListDevices();
            break;
        case 2:
            manager.ActivateAllDevices();
            break;
        case 3:
            manager.DeactivateAllDevices();
            break;
        case 4:
            manager.InteractionEventAll();
            break;
        case 0:
            cout << "Exiting...\n";
            break;
        default:
            cout << "Invalid choice, please try again.\n";
        }
    } while (choice != 0);

    return 0;
}
