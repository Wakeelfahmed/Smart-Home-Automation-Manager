#include "SmartHomeManager.h"

void SmartHomeManager::AddDevice(const shared_ptr<SmartDevice>& device) {
    devices.push_back(device);
}

void SmartHomeManager::ListDevices() const {
    for (const auto& device : devices) {
        device->ViewInfo();
        cout << "--------------------\n";
    }
}

void SmartHomeManager::ActivateAllDevices() {
    for (const auto& device : devices)
        device->Activate();
}

void SmartHomeManager::DeactivateAllDevices() {
    for (const auto& device : devices)
        device->Deactivate();
}

void SmartHomeManager::InteractionEventAll() const {
    for (const auto& device : devices)
        device->InteractionEvent();
}