#ifndef SMARTHOMEMANAGER_H
#define SMARTHOMEMANAGER_H

#include <vector>
#include <memory>
#include "SmartDevice.h"
#include "SecurityCamera.h"
#include "Thermostat.h"
#include "SmartSpeaker.h"
#include "SmartLight.h"

class SmartHomeManager {
private:
	vector<shared_ptr<SmartDevice>> devices;

public:
	void AddDevice(const shared_ptr<SmartDevice>& device);
	void ListDevices() const;
	void ActivateAllDevices();
	void DeactivateAllDevices();
	void InteractionEventAll() const;
};

#endif 
